package com.hardik.campusai.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;
import com.hardik.campusai.R;
import com.hardik.campusai.databinding.ActivitySubjectDetailBinding;
import com.hardik.campusai.models.Subject;
import com.hardik.campusai.models.Unit;

public class SubjectDetailActivity extends AppCompatActivity {

    public static final String EXTRA_SUBJECT_NAME = "subject_name";
    public static final String EXTRA_SUBJECT_CODE = "subject_code";
    public static final String EXTRA_UNITS_JSON = "units_json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivitySubjectDetailBinding binding = ActivitySubjectDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Setup toolbar
        binding.toolbar.setNavigationOnClickListener(v -> onBackPressed());

        // Get data from intent
        String subjectName = getIntent().getStringExtra(EXTRA_SUBJECT_NAME);
        String subjectCode = getIntent().getStringExtra(EXTRA_SUBJECT_CODE);
        String unitsJson = getIntent().getStringExtra(EXTRA_UNITS_JSON);

        // Set subject info
        binding.tvSubjectName.setText(subjectName != null ? subjectName : "Subject");
        binding.tvSubjectCode.setText(subjectCode != null ? subjectCode : "");
        binding.toolbar.setTitle(subjectName != null ? subjectName : "Subject Details");

        // Parse and display units
        if (unitsJson != null) {
            try {
                com.google.gson.Gson gson = new com.google.gson.Gson();
                com.google.gson.reflect.TypeToken<java.util.List<Unit>> typeToken =
                        new com.google.gson.reflect.TypeToken<java.util.List<Unit>>() {};
                java.util.List<Unit> units = gson.fromJson(unitsJson, typeToken.getType());

                if (units != null) {
                    for (Unit unit : units) {
                        addUnitCard(binding.unitsContainer, unit);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Dynamically adds a card for each unit with its topics.
     */
    private void addUnitCard(LinearLayout container, Unit unit) {
        LayoutInflater inflater = LayoutInflater.from(this);

        // Create a card programmatically
        MaterialCardView card = new MaterialCardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.bottomMargin = (int) (12 * getResources().getDisplayMetrics().density);
        card.setLayoutParams(cardParams);
        card.setRadius(12 * getResources().getDisplayMetrics().density);
        card.setCardElevation(1 * getResources().getDisplayMetrics().density);
        card.setStrokeWidth(0);
        card.setContentPadding(
                (int) (16 * getResources().getDisplayMetrics().density),
                (int) (16 * getResources().getDisplayMetrics().density),
                (int) (16 * getResources().getDisplayMetrics().density),
                (int) (16 * getResources().getDisplayMetrics().density)
        );

        LinearLayout cardContent = new LinearLayout(this);
        cardContent.setOrientation(LinearLayout.VERTICAL);

        // Unit title
        TextView unitTitle = new TextView(this);
        unitTitle.setText(unit.getName());
        unitTitle.setTextSize(15);
        unitTitle.setTextColor(getColor(R.color.primary));
        unitTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        cardContent.addView(unitTitle);

        // Topics
        if (unit.getTopics() != null) {
            for (int i = 0; i < unit.getTopics().size(); i++) {
                String topic = unit.getTopics().get(i);
                TextView topicView = new TextView(this);
                topicView.setText("• " + topic);
                topicView.setTextSize(14);
                topicView.setTextColor(getColor(R.color.on_surface_variant));
                topicView.setPadding(0, (int) (6 * getResources().getDisplayMetrics().density), 0, 0);
                topicView.setLineSpacing(4, 1);
                cardContent.addView(topicView);
            }
        }

        card.addView(cardContent);
        container.addView(card);
    }
}
