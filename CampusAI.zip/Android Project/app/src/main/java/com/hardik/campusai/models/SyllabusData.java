package com.hardik.campusai.models;

import java.util.List;

/**
 * Root model for syllabus JSON data.
 */
public class SyllabusData {
    private List<Course> courses;

    public SyllabusData() {
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }
}
