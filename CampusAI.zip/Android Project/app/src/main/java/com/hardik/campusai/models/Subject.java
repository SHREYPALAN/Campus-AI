package com.hardik.campusai.models;

import java.util.List;

/**
 * Represents a subject in the syllabus.
 */
public class Subject {
    private String name;
    private String code;
    private List<Unit> units;
    private String semesterName; // Set dynamically, not from JSON

    public Subject() {
    }

    public Subject(String name, String code, List<Unit> units) {
        this.name = name;
        this.code = code;
        this.units = units;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<Unit> getUnits() {
        return units;
    }

    public void setUnits(List<Unit> units) {
        this.units = units;
    }

    public String getSemesterName() {
        return semesterName;
    }

    public void setSemesterName(String semesterName) {
        this.semesterName = semesterName;
    }

    public int getTotalTopics() {
        if (units == null) return 0;
        int count = 0;
        for (Unit unit : units) {
            if (unit.getTopics() != null) {
                count += unit.getTopics().size();
            }
        }
        return count;
    }
}
