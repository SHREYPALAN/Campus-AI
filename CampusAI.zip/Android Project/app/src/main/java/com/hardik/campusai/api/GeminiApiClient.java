package com.hardik.campusai.api;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hardik.campusai.utils.Constants;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Production-ready client for communicating with the Google Gemini API.
 * Features: retry logic, network checks, proper error handling, debug logging.
 */
public class GeminiApiClient {

    private static final String TAG = "GeminiApiClient";
    private static final String BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/";
    private static final MediaType JSON_MEDIA = MediaType.parse("application/json; charset=utf-8");

    // Single model — no fallback
    private static final String MODEL = "gemini-3-flash-preview";

    private static final int MAX_RETRIES = 1;
    private static final long RETRY_DELAY_MS = 5000;

    private final OkHttpClient client;
    private final Gson gson;


    // System instruction — detailed prompt for high-quality academic responses
    private static final String SYSTEM_PROMPT =
            "You are **CampusAI**, an expert academic study assistant built for BCA and MCA students " +
            "at Marwadi University, Rajkot, Gujarat.\n\n" +

            "## Your Role\n" +
            "- You are a friendly, knowledgeable tutor who explains concepts clearly.\n" +
            "- You help students prepare for university exams and understand subjects deeply.\n" +
            "- You cover all BCA/MCA subjects: C, Java, Python, Data Structures, DBMS, SQL, " +
            "Computer Networks, Operating Systems, Software Engineering, Web Technology, " +
            "Cloud Computing, AI/ML, Cyber Security, Android Development, and more.\n\n" +

            "## Response Rules (ALWAYS follow these)\n" +
            "1. **Keep answers concise** — aim for 150-300 words. Only go longer if the student asks for detail.\n" +
            "2. **Use structure** — always use headings, bullet points, or numbered lists. Never give a wall of text.\n" +
            "3. **Start with a one-line summary** — begin every answer with a brief definition or direct answer.\n" +
            "4. **Use examples** — include a short code snippet or real-world example when explaining programming or technical concepts.\n" +
            "5. **Exam focus** — when asked about 'important topics', give a prioritized list with brief reasons.\n" +
            "6. **Be student-friendly** — use simple language. Avoid jargon unless you explain it.\n" +
            "7. **Comparison questions** — use a table format when comparing two or more things (e.g., TCP vs UDP).\n" +
            "8. **Code questions** — provide clean, commented code. Mention the language. Keep it short.\n" +
            "9. **Don't repeat the question** back in your answer.\n" +
            "10. **If unsure**, say so honestly rather than giving wrong information.\n\n" +

            "## Example Format\n" +
            "**Question:** What is normalization in DBMS?\n" +
            "**Good Answer:**\n" +
            "Normalization is the process of organizing database tables to reduce data redundancy.\n\n" +
            "**Key Normal Forms:**\n" +
            "• **1NF** — No repeating groups, atomic values only\n" +
            "• **2NF** — 1NF + no partial dependencies\n" +
            "• **3NF** — 2NF + no transitive dependencies\n" +
            "• **BCNF** — Every determinant is a candidate key\n\n" +
            "💡 *For exams, focus on 1NF to 3NF with examples.*";

    public interface GeminiCallback {
        void onSuccess(String response);
        void onError(String error);
    }

    public GeminiApiClient() {
        client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
        gson = new Gson();
    }

    /**
     * Checks if the device has an active internet connection.
     */
    public static boolean isNetworkAvailable(Context context) {
        if (context == null) return false;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;

        NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
        if (capabilities == null) return false;

        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);
    }

    /**
     * Sends a message to the Gemini API with automatic retry and model fallback.
     */
    public void sendMessage(String userMessage, GeminiCallback callback) {
        String apiKey = Constants.GEMINI_API_KEY;

        // Debug: Log API key status (masked for security)
        if (apiKey != null && apiKey.length() > 8) {
            Log.d(TAG, "API Key: " + apiKey.substring(0, 4) + "****" +
                    apiKey.substring(apiKey.length() - 4) + " (len=" + apiKey.length() + ")");
        } else {
            Log.e(TAG, "API Key is null or too short!");
        }

        // Validate API key
        if (apiKey == null || apiKey.trim().isEmpty() || apiKey.equals("YOUR_API_KEY_HERE")) {
            callback.onError("API key not set. Please add your Gemini API key in Constants.java");
            return;
        }

        // Start request with retry support
        sendWithRetry(userMessage, apiKey, MODEL, 0, callback);
    }

    /**
     * Internal method that handles retry logic and model fallback.
     */
    private void sendWithRetry(String userMessage, String apiKey, String model,
                               int attempt, GeminiCallback callback) {

        String url = BASE_URL + model + ":generateContent?key=" + apiKey;
        Log.d(TAG, "Attempt " + (attempt + 1) + " | Model: " + model);
        Log.d(TAG, "Message: " + userMessage);

        // Build the JSON request body
        String jsonBody = buildRequestBody(userMessage);
        Log.d(TAG, "Request body: " + jsonBody);

        RequestBody body = RequestBody.create(jsonBody, JSON_MEDIA);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e(TAG, "Network failure (attempt " + (attempt + 1) + "): " + e.getMessage());

                // Retry on network failure
                if (attempt < MAX_RETRIES) {
                    Log.d(TAG, "Retrying in " + RETRY_DELAY_MS + "ms...");
                    retryAfterDelay(userMessage, apiKey, model, attempt + 1, callback);
                } else {
                    callback.onError("Network error. Please check your internet connection and try again.");
                }
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String responseBody = "";
                try {
                    responseBody = response.body() != null ? response.body().string() : "";
                    int code = response.code();
                    Log.d(TAG, "Response code: " + code);
                    Log.d(TAG, "Response: " + responseBody.substring(0, Math.min(500, responseBody.length())));

                    if (response.isSuccessful()) {
                        // Parse successful response
                        String text = parseGeminiResponse(responseBody);
                        if (text != null && !text.isEmpty()) {
                            callback.onSuccess(text);
                        } else {
                            callback.onError("AI returned an empty response. Please try rephrasing your question.");
                        }
                        return;
                    }

                    // Handle specific error codes
                    switch (code) {
                        case 404:
                            callback.onError("AI model not available. Please try again later.");
                            return;

                        case 429:
                            // Rate limited — do NOT retry (retrying makes it worse)
                            Log.e(TAG, "429 Rate limited. Full response: " + responseBody);
                            String rateLimitMsg = extractErrorMessage(responseBody);
                            callback.onError("Rate limit reached. Please wait 30-60 seconds before trying again.\n\nDetails: " + rateLimitMsg);
                            return;

                        case 500:
                        case 503:
                            // Server error — retry
                            if (attempt < MAX_RETRIES) {
                                Log.w(TAG, "Server error. Retrying...");
                                retryAfterDelay(userMessage, apiKey, model, attempt + 1, callback);
                            } else {
                                callback.onError("Gemini server is temporarily unavailable. Please try again shortly.");
                            }
                            return;

                        case 400:
                            // Bad request — extract actual error message
                            String errorDetail = extractErrorMessage(responseBody);
                            callback.onError("Request error: " + errorDetail);
                            return;

                        case 403:
                            callback.onError("API key invalid or restricted. Please verify your key at aistudio.google.com/apikey");
                            return;

                        default:
                            String msg = extractErrorMessage(responseBody);
                            callback.onError("Error (" + code + "): " + msg);
                    }

                } catch (Exception e) {
                    Log.e(TAG, "Parse error: " + e.getMessage() + "\nBody: " + responseBody, e);
                    callback.onError("Failed to process AI response. Please try again.");
                }
            }
        });
    }

    /**
     * Retries a request after a delay.
     */
    private void retryAfterDelay(String message, String apiKey, String model,
                                 int attempt, GeminiCallback callback) {
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                () -> sendWithRetry(message, apiKey, model, attempt, callback),
                RETRY_DELAY_MS * attempt
        );
    }

    /**
     * Builds the JSON request body for the Gemini API.
     */
    private String buildRequestBody(String userMessage) {
        JsonObject requestBody = new JsonObject();

        // System instruction
        JsonObject systemInstruction = new JsonObject();
        JsonArray systemPartsArray = new JsonArray();
        JsonObject systemPart = new JsonObject();
        systemPart.addProperty("text", SYSTEM_PROMPT);
        systemPartsArray.add(systemPart);
        systemInstruction.add("parts", systemPartsArray);
        requestBody.add("system_instruction", systemInstruction);

        // User content
        JsonObject content = new JsonObject();
        content.addProperty("role", "user");
        JsonArray parts = new JsonArray();
        JsonObject part = new JsonObject();
        part.addProperty("text", userMessage);
        parts.add(part);
        content.add("parts", parts);

        JsonArray contents = new JsonArray();
        contents.add(content);
        requestBody.add("contents", contents);

        // Generation config
        JsonObject generationConfig = new JsonObject();
        generationConfig.addProperty("temperature", 0.7);
        generationConfig.addProperty("maxOutputTokens", 2048);
        generationConfig.addProperty("topP", 0.95);
        requestBody.add("generationConfig", generationConfig);

        // Safety settings — be lenient for academic content
        JsonArray safetySettings = new JsonArray();
        String[] categories = {
                "HARM_CATEGORY_HARASSMENT",
                "HARM_CATEGORY_HATE_SPEECH",
                "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "HARM_CATEGORY_DANGEROUS_CONTENT"
        };
        for (String category : categories) {
            JsonObject setting = new JsonObject();
            setting.addProperty("category", category);
            setting.addProperty("threshold", "BLOCK_ONLY_HIGH");
            safetySettings.add(setting);
        }
        requestBody.add("safetySettings", safetySettings);

        return gson.toJson(requestBody);
    }

    /**
     * Extracts error message from Gemini API error response JSON.
     */
    private String extractErrorMessage(String responseBody) {
        try {
            JsonObject root = gson.fromJson(responseBody, JsonObject.class);
            if (root.has("error")) {
                JsonObject error = root.getAsJsonObject("error");
                if (error.has("message")) {
                    return error.get("message").getAsString();
                }
                if (error.has("status")) {
                    return error.get("status").getAsString();
                }
            }
        } catch (Exception ignored) {}
        return "Unknown error occurred";
    }

    /**
     * Parses the Gemini API JSON response and extracts the text content.
     */
    private String parseGeminiResponse(String jsonResponse) {
        try {
            JsonObject root = gson.fromJson(jsonResponse, JsonObject.class);

            // Check for error in response body
            if (root.has("error")) {
                String errorMsg = extractErrorMessage(jsonResponse);
                Log.e(TAG, "Response contains error: " + errorMsg);
                return null;
            }

            // Check for prompt feedback (blocked prompts)
            if (root.has("promptFeedback")) {
                JsonObject feedback = root.getAsJsonObject("promptFeedback");
                if (feedback.has("blockReason")) {
                    String reason = feedback.get("blockReason").getAsString();
                    Log.w(TAG, "Prompt blocked: " + reason);
                    return "Your question was blocked by safety filters (" + reason + "). Please try a different academic question.";
                }
            }

            JsonArray candidates = root.getAsJsonArray("candidates");

            if (candidates != null && candidates.size() > 0) {
                JsonObject firstCandidate = candidates.get(0).getAsJsonObject();

                // Check finish reason
                if (firstCandidate.has("finishReason")) {
                    String finishReason = firstCandidate.get("finishReason").getAsString();
                    Log.d(TAG, "Finish reason: " + finishReason);
                    if ("SAFETY".equals(finishReason)) {
                        return "This response was blocked by safety filters. Please try a different academic question.";
                    }
                }

                // Extract text content
                if (firstCandidate.has("content")) {
                    JsonObject contentObj = firstCandidate.getAsJsonObject("content");
                    if (contentObj != null && contentObj.has("parts")) {
                        JsonArray partsArray = contentObj.getAsJsonArray("parts");
                        if (partsArray != null && partsArray.size() > 0) {
                            StringBuilder fullText = new StringBuilder();
                            for (int i = 0; i < partsArray.size(); i++) {
                                JsonObject p = partsArray.get(i).getAsJsonObject();
                                if (p.has("text")) {
                                    fullText.append(p.get("text").getAsString());
                                }
                            }
                            return fullText.toString().trim();
                        }
                    }
                }
            }

            Log.e(TAG, "No valid candidates in response");
        } catch (Exception e) {
            Log.e(TAG, "Error parsing response: " + e.getMessage(), e);
        }
        return null;
    }
}

