package com.hardik.campusai.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;

import androidx.appcompat.app.AppCompatActivity;

import com.hardik.campusai.databinding.ActivitySplashBinding;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 2500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivitySplashBinding binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Fade-in + slide-up animation for app name
        AnimationSet animSet = new AnimationSet(true);
        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(1200);
        TranslateAnimation slideUp = new TranslateAnimation(0, 0, 80, 0);
        slideUp.setDuration(1200);
        animSet.addAnimation(fadeIn);
        animSet.addAnimation(slideUp);
        animSet.setFillAfter(true);

        binding.tvAppName.startAnimation(animSet);

        // Delayed fade-in for tagline
        AlphaAnimation taglineFade = new AlphaAnimation(0.0f, 1.0f);
        taglineFade.setDuration(1000);
        taglineFade.setStartOffset(500);
        taglineFade.setFillAfter(true);
        binding.tvTagline.startAnimation(taglineFade);

        // Fade-in for icon
        AlphaAnimation iconFade = new AlphaAnimation(0.0f, 1.0f);
        iconFade.setDuration(800);
        iconFade.setFillAfter(true);
        binding.tvAppIcon.startAnimation(iconFade);

        // Navigate to MainActivity after delay
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, SPLASH_DURATION);
    }
}
