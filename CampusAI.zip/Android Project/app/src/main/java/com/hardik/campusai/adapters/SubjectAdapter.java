package com.hardik.campusai.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.hardik.campusai.R;
import com.hardik.campusai.models.Subject;

import java.util.List;

/**
 * RecyclerView adapter for displaying subjects in the syllabus.
 */
public class SubjectAdapter extends RecyclerView.Adapter<SubjectAdapter.SubjectViewHolder> {

    private List<Subject> subjects;
    private final OnSubjectClickListener listener;

    public interface OnSubjectClickListener {
        void onSubjectClick(Subject subject);
    }

    public SubjectAdapter(List<Subject> subjects, OnSubjectClickListener listener) {
        this.subjects = subjects;
        this.listener = listener;
    }

    @NonNull
    @Override
    public SubjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_subject_card, parent, false);
        return new SubjectViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SubjectViewHolder holder, int position) {
        Subject subject = subjects.get(position);
        holder.bind(subject);
    }

    @Override
    public int getItemCount() {
        return subjects.size();
    }

    /**
     * Updates the adapter data and refreshes the list.
     */
    public void updateData(List<Subject> newSubjects) {
        this.subjects = newSubjects;
        notifyDataSetChanged();
    }

    class SubjectViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvSemesterTitle;
        private final TextView tvSubjectName;
        private final TextView tvSubjectCode;
        private final TextView tvTopicsCount;

        SubjectViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSemesterTitle = itemView.findViewById(R.id.tvSemesterTitle);
            tvSubjectName = itemView.findViewById(R.id.tvSubjectName);
            tvSubjectCode = itemView.findViewById(R.id.tvSubjectCode);
            tvTopicsCount = itemView.findViewById(R.id.tvTopicsCount);

            itemView.setOnClickListener(v -> {
                int pos = getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION && listener != null) {
                    listener.onSubjectClick(subjects.get(pos));
                }
            });
        }

        void bind(Subject subject) {
            tvSemesterTitle.setText(subject.getSemesterName());
            tvSubjectName.setText(subject.getName());
            tvSubjectCode.setText(subject.getCode());

            int topicCount = subject.getTotalTopics();
            tvTopicsCount.setText(topicCount + " topics");
        }
    }
}
