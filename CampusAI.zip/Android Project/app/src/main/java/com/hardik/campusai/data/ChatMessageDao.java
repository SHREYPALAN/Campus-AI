package com.hardik.campusai.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.hardik.campusai.models.ChatMessage;

import java.util.List;

/**
 * Data Access Object for chat messages.
 * Room generates the implementation at compile time.
 */
@Dao
public interface ChatMessageDao {

    /**
     * Insert a single message.
     * Returns the auto-generated row ID.
     */
    @Insert
    long insert(ChatMessage message);

    /**
     * Get all messages ordered by timestamp (oldest first).
     * Returns LiveData so the UI auto-updates when data changes.
     */
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    LiveData<List<ChatMessage>> getAllMessages();

    /**
     * Get all messages (synchronous — for loading in background).
     */
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    List<ChatMessage> getAllMessagesSync();

    /**
     * Get only the last N messages (for limiting history).
     */
    @Query("SELECT * FROM (SELECT * FROM chat_messages ORDER BY timestamp DESC LIMIT :limit) ORDER BY timestamp ASC")
    List<ChatMessage> getRecentMessages(int limit);

    /**
     * Get the count of all messages.
     */
    @Query("SELECT COUNT(*) FROM chat_messages")
    int getMessageCount();

    /**
     * Delete all messages (clear chat).
     */
    @Query("DELETE FROM chat_messages")
    void deleteAll();

    /**
     * Delete old messages, keeping only the last N.
     */
    @Query("DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY timestamp DESC LIMIT :keepCount)")
    void deleteOldMessages(int keepCount);
}
