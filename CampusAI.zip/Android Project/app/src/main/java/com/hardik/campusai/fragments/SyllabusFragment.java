package com.hardik.campusai.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.chip.Chip;
import com.hardik.campusai.R;
import com.hardik.campusai.activities.SubjectDetailActivity;
import com.hardik.campusai.adapters.SubjectAdapter;
import com.hardik.campusai.databinding.FragmentSyllabusBinding;
import com.hardik.campusai.models.Course;
import com.hardik.campusai.models.Semester;
import com.hardik.campusai.models.Subject;
import com.hardik.campusai.models.SyllabusData;
import com.hardik.campusai.utils.JsonParser;

import java.util.ArrayList;
import java.util.List;

public class SyllabusFragment extends Fragment implements SubjectAdapter.OnSubjectClickListener {

    private FragmentSyllabusBinding binding;
    private SubjectAdapter adapter;
    private SyllabusData syllabusData;
    private String currentCourse = "BCA";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentSyllabusBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Load syllabus data from JSON
        syllabusData = JsonParser.parseSyllabus(requireContext());

        // Setup RecyclerView
        adapter = new SubjectAdapter(new ArrayList<>(), this);
        binding.rvSyllabus.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSyllabus.setAdapter(adapter);

        // Setup course chip listeners
        binding.chipBCA.setOnClickListener(v -> {
            currentCourse = "BCA";
            loadSubjects();
        });

        binding.chipMCA.setOnClickListener(v -> {
            currentCourse = "MCA";
            loadSubjects();
        });

        // Load initial data
        loadSubjects();
    }

    /**
     * Loads subjects for the currently selected course.
     */
    private void loadSubjects() {
        if (syllabusData == null || syllabusData.getCourses() == null) return;

        List<Subject> allSubjects = new ArrayList<>();

        for (Course course : syllabusData.getCourses()) {
            if (course.getName().equalsIgnoreCase(currentCourse)) {
                if (course.getSemesters() != null) {
                    for (Semester semester : course.getSemesters()) {
                        if (semester.getSubjects() != null) {
                            for (Subject subject : semester.getSubjects()) {
                                subject.setSemesterName("Semester " + semester.getNumber());
                                allSubjects.add(subject);
                            }
                        }
                    }
                }
                break;
            }
        }

        adapter.updateData(allSubjects);
    }

    @Override
    public void onSubjectClick(Subject subject) {
        // Open SubjectDetailActivity
        Intent intent = new Intent(requireContext(), SubjectDetailActivity.class);
        intent.putExtra(SubjectDetailActivity.EXTRA_SUBJECT_NAME, subject.getName());
        intent.putExtra(SubjectDetailActivity.EXTRA_SUBJECT_CODE, subject.getCode());

        if (subject.getUnits() != null) {
            String unitsJson = new com.google.gson.Gson().toJson(subject.getUnits());
            intent.putExtra(SubjectDetailActivity.EXTRA_UNITS_JSON, unitsJson);
        }

        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
