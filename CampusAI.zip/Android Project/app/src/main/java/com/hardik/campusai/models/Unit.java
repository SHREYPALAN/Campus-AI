package com.hardik.campusai.models;

import java.util.List;

/**
 * Represents a unit within a subject.
 */
public class Unit {
    private String name;
    private List<String> topics;

    public Unit() {
    }

    public Unit(String name, List<String> topics) {
        this.name = name;
        this.topics = topics;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getTopics() {
        return topics;
    }

    public void setTopics(List<String> topics) {
        this.topics = topics;
    }
}
