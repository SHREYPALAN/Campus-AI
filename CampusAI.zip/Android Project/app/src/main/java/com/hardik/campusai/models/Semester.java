package com.hardik.campusai.models;

import java.util.List;

/**
 * Represents a semester in a course.
 */
public class Semester {
    private int number;
    private String name;
    private List<Subject> subjects;

    public Semester() {
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }
}
