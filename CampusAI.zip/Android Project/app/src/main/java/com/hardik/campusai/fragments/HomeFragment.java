package com.hardik.campusai.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.hardik.campusai.R;
import com.hardik.campusai.activities.MainActivity;
import com.hardik.campusai.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupCardClicks();
    }

    /**
     * Sets up click listeners on dashboard cards to navigate to corresponding tabs.
     */
    private void setupCardClicks() {
        binding.cardSyllabus.setOnClickListener(v -> navigateToTab(R.id.nav_syllabus));
        binding.cardPapers.setOnClickListener(v -> navigateToTab(R.id.nav_papers));
        binding.cardAIChat.setOnClickListener(v -> navigateToTab(R.id.nav_ai_chat));
        binding.cardAbout.setOnClickListener(v -> navigateToTab(R.id.nav_about));
    }

    /**
     * Navigates to a specific bottom navigation tab via MainActivity.
     */
    private void navigateToTab(int navItemId) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).navigateToTab(navItemId);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
