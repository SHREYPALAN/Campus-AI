package com.hardik.campusai.fragments;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.chip.Chip;
import com.google.android.material.snackbar.Snackbar;
import com.hardik.campusai.R;
import com.hardik.campusai.adapters.ChatAdapter;
import com.hardik.campusai.api.GeminiApiClient;
import com.hardik.campusai.databinding.FragmentAiChatBinding;
import com.hardik.campusai.models.ChatMessage;
import com.hardik.campusai.viewmodel.ChatViewModel;

import java.util.ArrayList;
import java.util.List;

public class AIChatFragment extends Fragment {

    private FragmentAiChatBinding binding;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> chatMessages;
    private GeminiApiClient geminiClient;
    private ChatViewModel chatViewModel;
    private String lastFailedMessage = null;
    private boolean isWaitingForResponse = false;
    private boolean isHistoryLoaded = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentAiChatBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize
        chatMessages = new ArrayList<>();
        geminiClient = new GeminiApiClient();

        // Setup ViewModel
        chatViewModel = new ViewModelProvider(this).get(ChatViewModel.class);

        // Setup RecyclerView
        chatAdapter = new ChatAdapter(chatMessages, this::retryLastMessage);
        LinearLayoutManager layoutManager = new LinearLayoutManager(requireContext());
        layoutManager.setStackFromEnd(true);
        binding.rvChat.setLayoutManager(layoutManager);
        binding.rvChat.setAdapter(chatAdapter);

        // Setup send button — initially disabled
        binding.fabSend.setEnabled(false);
        binding.fabSend.setAlpha(0.5f);
        binding.fabSend.setOnClickListener(v -> sendMessage());

        // Enable/disable send button based on input
        binding.etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateSendButtonState();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Send on keyboard action button
        binding.etMessage.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) {
                sendMessage();
                return true;
            }
            return false;
        });

        // Setup suggested question chips
        setupSuggestedChips();

        // Setup clear chat button in toolbar
        binding.chatToolbar.inflateMenu(R.menu.menu_chat);
        binding.chatToolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_clear_chat) {
                showClearChatDialog();
                return true;
            }
            return false;
        });

        // ─── Observe chat history from Room DB ───
        chatViewModel.getAllMessages().observe(getViewLifecycleOwner(), messages -> {
            if (!isHistoryLoaded) {
                isHistoryLoaded = true;
                loadChatHistory(messages);
            }
        });
    }

    /**
     * Loads saved chat history into the RecyclerView.
     * Called once when LiveData first emits.
     */
    private void loadChatHistory(List<ChatMessage> savedMessages) {
        if (savedMessages != null && !savedMessages.isEmpty()) {
            // We have saved history — load it
            chatMessages.clear();
            chatMessages.addAll(savedMessages);
            chatAdapter.notifyDataSetChanged();
            scrollToBottom();

            // Hide suggestion chips since there's already conversation
            binding.suggestedScrollView.setVisibility(View.GONE);
        } else {
            // No history — show welcome message and save it
            ChatMessage welcome = ChatMessage.aiMessage(getString(R.string.chat_welcome));
            chatMessages.add(welcome);
            chatAdapter.notifyItemInserted(0);
            chatViewModel.insert(welcome);
        }
    }

    /**
     * Shows confirmation dialog for clearing chat.
     */
    private void showClearChatDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Clear Chat")
                .setMessage("Delete all chat history? This cannot be undone.")
                .setPositiveButton("Clear", (dialog, which) -> {
                    // Clear DB
                    chatViewModel.clearChat();

                    // Clear UI
                    chatMessages.clear();
                    chatAdapter.notifyDataSetChanged();

                    // Re-add welcome message
                    ChatMessage welcome = ChatMessage.aiMessage(getString(R.string.chat_welcome));
                    chatMessages.add(welcome);
                    chatAdapter.notifyItemInserted(0);
                    chatViewModel.insert(welcome);

                    // Show suggestions again
                    binding.suggestedScrollView.setVisibility(View.VISIBLE);

                    Snackbar.make(binding.getRoot(), "Chat cleared", Snackbar.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Sets up click listeners for suggested question chips.
     */
    private void setupSuggestedChips() {
        View.OnClickListener chipListener = v -> {
            String question = ((Chip) v).getText().toString();
            binding.etMessage.setText(question);
            sendMessage();
        };

        binding.chipSuggestion1.setOnClickListener(chipListener);
        binding.chipSuggestion2.setOnClickListener(chipListener);
        binding.chipSuggestion3.setOnClickListener(chipListener);
        binding.chipSuggestion4.setOnClickListener(chipListener);
    }

    /**
     * Sends the current message to the AI.
     */
    private void sendMessage() {
        if (!isFragmentAlive()) return;

        String message = binding.etMessage.getText().toString().trim();
        if (message.isEmpty() || isWaitingForResponse) return;

        // If currently animating a previous response, complete it instantly
        if (chatAdapter.isAnimating()) {
            chatAdapter.stopCurrentAnimation();
        }

        // Check network
        if (!GeminiApiClient.isNetworkAvailable(getContext())) {
            Snackbar.make(binding.getRoot(), "No internet connection", Snackbar.LENGTH_LONG)
                    .setAction("Retry", v -> sendMessage())
                    .show();
            return;
        }

        // Add user message + save to DB
        ChatMessage userMsg = ChatMessage.userMessage(message);
        chatMessages.add(userMsg);
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        scrollToBottom();
        chatViewModel.insert(userMsg);  // ← Save to Room

        binding.etMessage.setText("");
        hideKeyboard();

        // Hide suggestions
        binding.suggestedScrollView.setVisibility(View.GONE);

        // Show typing indicator (animated dots)
        showTypingIndicator();

        // Call Gemini API
        lastFailedMessage = message;
        geminiClient.sendMessage(message, new GeminiApiClient.GeminiCallback() {
            @Override
            public void onSuccess(String response) {
                if (!isFragmentAlive()) return;
                requireActivity().runOnUiThread(() -> {
                    if (!isFragmentAlive()) return;
                    removeTypingIndicator();
                    lastFailedMessage = null;
                    // Add AI message with typing animation + save to DB
                    addAIMessageAnimated(response);
                });
            }

            @Override
            public void onError(String error) {
                if (!isFragmentAlive()) return;
                requireActivity().runOnUiThread(() -> {
                    if (!isFragmentAlive()) return;
                    removeTypingIndicator();
                    addErrorMessage("⚠️ " + error);

                    if (binding != null) {
                        Snackbar.make(binding.getRoot(), "Failed to get response", Snackbar.LENGTH_LONG)
                                .setAction("Retry", v -> retryLastMessage())
                                .show();
                    }
                });
            }
        });
    }

    /**
     * Retries the last failed message.
     */
    private void retryLastMessage() {
        if (lastFailedMessage == null || !isFragmentAlive()) return;

        showTypingIndicator();

        geminiClient.sendMessage(lastFailedMessage, new GeminiApiClient.GeminiCallback() {
            @Override
            public void onSuccess(String response) {
                if (!isFragmentAlive()) return;
                requireActivity().runOnUiThread(() -> {
                    if (!isFragmentAlive()) return;
                    removeTypingIndicator();
                    lastFailedMessage = null;
                    addAIMessageAnimated(response);
                });
            }

            @Override
            public void onError(String error) {
                if (!isFragmentAlive()) return;
                requireActivity().runOnUiThread(() -> {
                    if (!isFragmentAlive()) return;
                    removeTypingIndicator();
                    addErrorMessage("⚠️ Retry failed: " + error);
                });
            }
        });
    }

    // ─────────────────────────────────────────────────
    // Message helpers (all save to DB)
    // ─────────────────────────────────────────────────

    /**
     * Adds an AI message with typing animation and saves to DB.
     */
    private void addAIMessageAnimated(String message) {
        if (!isFragmentAlive()) return;

        ChatMessage aiMsg = ChatMessage.aiMessage(message);
        chatMessages.add(aiMsg);
        int position = chatMessages.size() - 1;
        chatAdapter.notifyItemInserted(position);
        scrollToBottom();

        // Save to DB immediately (full text)
        chatViewModel.insert(aiMsg);

        // Start typing animation
        binding.tvStatus.setText("Typing...");

        binding.rvChat.postDelayed(() -> {
            if (!isFragmentAlive()) return;
            chatAdapter.startTypingAnimation(position, binding.rvChat, () -> {
                if (isFragmentAlive()) {
                    binding.tvStatus.setText("Online");
                    updateSendButtonState();
                }
            });
        }, 150);
    }

    /**
     * Adds an error message instantly and saves to DB.
     */
    private void addErrorMessage(String message) {
        if (!isFragmentAlive()) return;
        ChatMessage errorMsg = ChatMessage.errorMessage(message);
        chatMessages.add(errorMsg);
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        scrollToBottom();
        chatViewModel.insert(errorMsg);  // Save errors too for context
    }

    // ─────────────────────────────────────────────────
    // Typing indicator (dots — before API response)
    // ─────────────────────────────────────────────────

    private void showTypingIndicator() {
        if (isWaitingForResponse) return;
        isWaitingForResponse = true;

        chatMessages.add(ChatMessage.typingIndicator());
        chatAdapter.notifyItemInserted(chatMessages.size() - 1);
        scrollToBottom();

        updateSendButtonState();
        binding.tvStatus.setText("Thinking...");
    }

    private void removeTypingIndicator() {
        if (!isWaitingForResponse) return;
        isWaitingForResponse = false;

        for (int i = chatMessages.size() - 1; i >= 0; i--) {
            if (chatMessages.get(i).isTyping()) {
                chatMessages.remove(i);
                chatAdapter.notifyItemRemoved(i);
                break;
            }
        }

        updateSendButtonState();
    }

    // ─────────────────────────────────────────────────
    // UI State
    // ─────────────────────────────────────────────────

    private void updateSendButtonState() {
        if (binding == null) return;
        boolean hasText = binding.etMessage.getText().toString().trim().length() > 0;
        boolean canSend = hasText && !isWaitingForResponse;
        binding.fabSend.setEnabled(canSend);
        binding.fabSend.setAlpha(canSend ? 1.0f : 0.5f);
    }

    // ─────────────────────────────────────────────────
    // Utilities
    // ─────────────────────────────────────────────────

    private void scrollToBottom() {
        if (binding != null && chatMessages.size() > 0) {
            binding.rvChat.postDelayed(() -> {
                if (binding != null) {
                    binding.rvChat.smoothScrollToPosition(chatMessages.size() - 1);
                }
            }, 100);
        }
    }

    private boolean isFragmentAlive() {
        return isAdded() && getActivity() != null && binding != null && getView() != null;
    }

    private void hideKeyboard() {
        if (getActivity() == null || binding == null) return;
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(binding.etMessage.getWindowToken(), 0);
        }
    }

    @Override
    public void onDestroyView() {
        if (chatAdapter != null) {
            chatAdapter.stopCurrentAnimation();
        }
        super.onDestroyView();
        binding = null;
    }
}
