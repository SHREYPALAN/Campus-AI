package com.hardik.campusai.utils;

import android.os.Handler;
import android.os.Looper;

/**
 * Animates text appearing character-by-character like ChatGPT.
 * Runs on main thread using Handler. Can be stopped safely at any time.
 */
public class TypingAnimator {

    // Speed: characters per tick
    private static final int CHARS_PER_TICK = 2;
    // Base delay between each tick (ms)
    private static final long BASE_DELAY_MS = 18;
    // Slight pause at punctuation for natural feel
    private static final long PUNCTUATION_DELAY_MS = 60;
    // Initial delay before typing starts (simulate "thinking")
    private static final long START_DELAY_MS = 300;

    private final Handler handler;
    private final String fullText;
    private final TypingListener listener;
    private int currentIndex = 0;
    private boolean isRunning = false;
    private boolean isCancelled = false;
    private Runnable tickRunnable;

    /**
     * Callback interface for typing animation events.
     */
    public interface TypingListener {
        /** Called each tick with the text revealed so far. */
        void onTextUpdate(String currentText);

        /** Called when the full text has been revealed (or on explicit complete). */
        void onComplete(String fullText);
    }

    public TypingAnimator(String fullText, TypingListener listener) {
        this.fullText = fullText;
        this.listener = listener;
        this.handler = new Handler(Looper.getMainLooper());
    }

    /**
     * Starts the typing animation with an initial delay.
     */
    public void start() {
        if (isRunning || isCancelled) return;
        isRunning = true;
        currentIndex = 0;

        // Blinking cursor effect at start
        listener.onTextUpdate("▌");

        handler.postDelayed(this::nextTick, START_DELAY_MS);
    }

    /**
     * Processes the next tick — reveals a few more characters.
     */
    private void nextTick() {
        if (isCancelled || !isRunning) return;

        if (currentIndex >= fullText.length()) {
            // Done typing
            isRunning = false;
            listener.onTextUpdate(fullText);
            listener.onComplete(fullText);
            return;
        }

        // Advance by CHARS_PER_TICK characters
        int end = Math.min(currentIndex + CHARS_PER_TICK, fullText.length());
        currentIndex = end;

        // Show text so far + blinking cursor
        String displayText = fullText.substring(0, currentIndex);
        if (currentIndex < fullText.length()) {
            displayText += "▌";  // Cursor while still typing
        }
        listener.onTextUpdate(displayText);

        // Calculate delay — add pause at punctuation
        long delay = BASE_DELAY_MS;
        if (currentIndex > 0 && currentIndex <= fullText.length()) {
            char lastChar = fullText.charAt(currentIndex - 1);
            if (lastChar == '.' || lastChar == '!' || lastChar == '?' || lastChar == '\n') {
                delay = PUNCTUATION_DELAY_MS;
            } else if (lastChar == ',' || lastChar == ';' || lastChar == ':') {
                delay = PUNCTUATION_DELAY_MS / 2;
            }
        }

        // Schedule next tick
        tickRunnable = this::nextTick;
        handler.postDelayed(tickRunnable, delay);
    }

    /**
     * Stops the animation and immediately shows the full text.
     * Safe to call from any thread.
     */
    public void completeImmediately() {
        isCancelled = true;
        isRunning = false;
        handler.removeCallbacksAndMessages(null);

        // Show full text without cursor
        new Handler(Looper.getMainLooper()).post(() -> {
            listener.onTextUpdate(fullText);
            listener.onComplete(fullText);
        });
    }

    /**
     * Cancels the animation without completing.
     * Leaves the text at whatever was revealed so far.
     */
    public void cancel() {
        isCancelled = true;
        isRunning = false;
        handler.removeCallbacksAndMessages(null);
    }

    /**
     * Whether the animation is currently running.
     */
    public boolean isRunning() {
        return isRunning;
    }
}
