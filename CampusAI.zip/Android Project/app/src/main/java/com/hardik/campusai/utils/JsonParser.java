package com.hardik.campusai.utils;

import android.content.Context;

import com.google.gson.Gson;
import com.hardik.campusai.models.SyllabusData;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Utility class for parsing JSON files from assets.
 */
public class JsonParser {

    /**
     * Reads and parses the syllabus.json file from the assets folder.
     */
    public static SyllabusData parseSyllabus(Context context) {
        try {
            String json = readJsonFromAssets(context, "syllabus.json");
            Gson gson = new Gson();
            return gson.fromJson(json, SyllabusData.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Reads a JSON file from the assets folder and returns it as a string.
     */
    public static String readJsonFromAssets(Context context, String fileName) {
        StringBuilder sb = new StringBuilder();
        try {
            InputStream is = context.getAssets().open(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}
