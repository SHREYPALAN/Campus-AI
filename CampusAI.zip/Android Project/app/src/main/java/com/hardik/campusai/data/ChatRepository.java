package com.hardik.campusai.data;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.hardik.campusai.models.ChatMessage;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Repository for chat messages.
 * Abstracts the data layer — all DB operations run on background threads.
 */
public class ChatRepository {

    private final ChatMessageDao chatMessageDao;
    private final LiveData<List<ChatMessage>> allMessages;
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    // Max messages to keep in DB (auto-cleanup)
    private static final int MAX_MESSAGES = 200;

    public ChatRepository(Application application) {
        ChatDatabase database = ChatDatabase.getInstance(application);
        chatMessageDao = database.chatMessageDao();
        allMessages = chatMessageDao.getAllMessages();
    }

    /**
     * Returns LiveData of all messages — auto-updates the UI.
     */
    public LiveData<List<ChatMessage>> getAllMessages() {
        return allMessages;
    }

    /**
     * Inserts a message in the background thread.
     * Also cleans up old messages if over the limit.
     */
    public void insert(ChatMessage message) {
        executor.execute(() -> {
            chatMessageDao.insert(message);
            // Auto-cleanup: keep only last MAX_MESSAGES
            int count = chatMessageDao.getMessageCount();
            if (count > MAX_MESSAGES) {
                chatMessageDao.deleteOldMessages(MAX_MESSAGES);
            }
        });
    }

    /**
     * Deletes all messages in background thread (clear chat).
     */
    public void deleteAll() {
        executor.execute(chatMessageDao::deleteAll);
    }

    /**
     * Loads recent messages synchronously (call from background thread only).
     */
    public List<ChatMessage> getRecentMessagesSync(int limit) {
        return chatMessageDao.getRecentMessages(limit);
    }
}
