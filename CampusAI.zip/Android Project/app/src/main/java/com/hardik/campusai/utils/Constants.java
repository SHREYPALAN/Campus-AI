package com.hardik.campusai.utils;

/**
 * Application constants.
 */
public class Constants {

    /**
     * Gemini API Key - Replace with your actual key from Google AI Studio.
     *
     * To get your API key:
     * 1. Go to https://aistudio.google.com/apikey
     * 2. Sign in with your Google account
     * 3. Click "Create API Key"
     * 4. Copy the key and paste it below
     */
    public static final String GEMINI_API_KEY = "AIzaSyCo1p_ghQU_7eVgY6pOmtR7v-hgV7i09EE";


    // App Info
    public static final String APP_VERSION = "1.0";
    public static final String DEVELOPER_NAME = "Hardik";
    public static final String UNIVERSITY_NAME = "Marwadi University, Rajkot";
}
