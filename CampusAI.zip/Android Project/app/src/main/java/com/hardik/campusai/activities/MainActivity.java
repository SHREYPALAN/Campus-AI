package com.hardik.campusai.activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.hardik.campusai.R;
import com.hardik.campusai.databinding.ActivityMainBinding;
import com.hardik.campusai.fragments.AboutFragment;
import com.hardik.campusai.fragments.AIChatFragment;
import com.hardik.campusai.fragments.HomeFragment;
import com.hardik.campusai.fragments.PapersFragment;
import com.hardik.campusai.fragments.SyllabusFragment;

import java.util.ArrayDeque;
import java.util.Deque;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    // Tracks navigation history as a stack of nav item IDs
    private final Deque<Integer> navStack = new ArrayDeque<>();
    private boolean isNavigatingBack = false;
    private long lastBackPressTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Load home fragment by default
        if (savedInstanceState == null) {
            navStack.push(R.id.nav_home);
            loadFragment(new HomeFragment(), false);
        }

        // Bottom navigation listener
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            // If we're navigating back programmatically, just load the fragment
            if (isNavigatingBack) {
                loadFragment(createFragment(item.getItemId()), false);
                return true;
            }

            int id = item.getItemId();

            // Don't reload the same fragment
            if (!navStack.isEmpty() && navStack.peek() == id) {
                return true;
            }

            // Push to navigation stack and load
            navStack.push(id);
            loadFragment(createFragment(id), true);
            return true;
        });
    }

    /**
     * Creates the correct fragment for a given nav item ID.
     */
    private Fragment createFragment(int navItemId) {
        if (navItemId == R.id.nav_home) return new HomeFragment();
        if (navItemId == R.id.nav_syllabus) return new SyllabusFragment();
        if (navItemId == R.id.nav_ai_chat) return new AIChatFragment();
        if (navItemId == R.id.nav_papers) return new PapersFragment();
        if (navItemId == R.id.nav_about) return new AboutFragment();
        return new HomeFragment();
    }

    /**
     * Loads a fragment into the container with optional animation.
     */
    private void loadFragment(Fragment fragment, boolean animate) {
        var transaction = getSupportFragmentManager().beginTransaction();
        if (animate) {
            transaction.setCustomAnimations(
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
            );
        }
        transaction.replace(R.id.fragmentContainer, fragment)
                .commit();
    }

    /**
     * Handles back press: go to previous tab, or exit from Home with double-press.
     */
    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        // If there's navigation history, go back to previous tab
        if (navStack.size() > 1) {
            navStack.pop(); // Remove current
            int previousId = navStack.peek(); // Get previous

            isNavigatingBack = true;
            binding.bottomNavigation.setSelectedItemId(previousId);
            isNavigatingBack = false;
            return;
        }

        // Already on Home — double press to exit
        if (System.currentTimeMillis() - lastBackPressTime < 2000) {
            super.onBackPressed();
            return;
        }

        lastBackPressTime = System.currentTimeMillis();
        Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
    }

    /**
     * Called from HomeFragment to navigate to a specific tab.
     */
    public void navigateToTab(int navItemId) {
        binding.bottomNavigation.setSelectedItemId(navItemId);
    }
}
