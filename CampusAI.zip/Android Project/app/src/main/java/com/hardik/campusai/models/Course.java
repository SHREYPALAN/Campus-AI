package com.hardik.campusai.models;

import java.util.List;

/**
 * Represents a course (BCA or MCA).
 */
public class Course {
    private String name;
    private String fullName;
    private List<Semester> semesters;

    public Course() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public List<Semester> getSemesters() {
        return semesters;
    }

    public void setSemesters(List<Semester> semesters) {
        this.semesters = semesters;
    }
}
