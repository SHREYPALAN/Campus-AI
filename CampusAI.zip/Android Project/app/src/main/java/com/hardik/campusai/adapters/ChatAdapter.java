package com.hardik.campusai.adapters;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.hardik.campusai.R;
import com.hardik.campusai.models.ChatMessage;
import com.hardik.campusai.utils.TypingAnimator;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Multi-viewtype RecyclerView adapter for ChatGPT-style chat messages.
 * Supports USER, AI, and TYPING view types with typing animation.
 */
public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_USER = 0;
    private static final int VIEW_AI = 1;
    private static final int VIEW_TYPING = 2;

    private final List<ChatMessage> messages;
    private final OnRetryClickListener retryListener;
    private int lastAnimatedPosition = -1;

    // Currently running typing animation
    private TypingAnimator currentAnimator = null;
    private int animatingPosition = -1;

    public interface OnRetryClickListener {
        void onRetry();
    }

    public ChatAdapter(List<ChatMessage> messages, OnRetryClickListener retryListener) {
        this.messages = messages;
        this.retryListener = retryListener;
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage msg = messages.get(position);
        switch (msg.getType()) {
            case ChatMessage.TYPE_USER:
                return VIEW_USER;
            case ChatMessage.TYPE_TYPING:
                return VIEW_TYPING;
            default:
                return VIEW_AI;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        switch (viewType) {
            case VIEW_USER:
                return new UserViewHolder(inflater.inflate(R.layout.item_user_message, parent, false));
            case VIEW_TYPING:
                return new TypingViewHolder(inflater.inflate(R.layout.item_typing_indicator, parent, false));
            default:
                return new AIViewHolder(inflater.inflate(R.layout.item_ai_message, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMessage msg = messages.get(position);

        if (holder instanceof UserViewHolder) {
            ((UserViewHolder) holder).bind(msg);
        } else if (holder instanceof AIViewHolder) {
            ((AIViewHolder) holder).bind(msg, position);
        } else if (holder instanceof TypingViewHolder) {
            ((TypingViewHolder) holder).startAnimation();
        }

        // Fade-in + slide-up animation for new messages
        if (position > lastAnimatedPosition) {
            animateItem(holder.itemView);
            lastAnimatedPosition = position;
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    // ─────────────────────────────────────────────────
    // Typing animation control (called from Fragment)
    // ─────────────────────────────────────────────────

    /**
     * Starts typing animation on the last AI message.
     * The message should already be added to the list with the full text.
     */
    public void startTypingAnimation(int position, RecyclerView recyclerView,
                                     TypingAnimationCallback callback) {
        // Cancel any existing animation
        stopCurrentAnimation();

        if (position < 0 || position >= messages.size()) return;

        ChatMessage msg = messages.get(position);
        String fullText = msg.getMessage();
        animatingPosition = position;

        // Set message to empty initially — animation will fill it
        msg.setMessage("");
        notifyItemChanged(position);

        currentAnimator = new TypingAnimator(fullText, new TypingAnimator.TypingListener() {
            @Override
            public void onTextUpdate(String currentText) {
                if (animatingPosition >= 0 && animatingPosition < messages.size()) {
                    messages.get(animatingPosition).setMessage(currentText);
                    notifyItemChanged(animatingPosition, "text_update");
                    // Auto-scroll during typing
                    if (recyclerView != null) {
                        recyclerView.scrollToPosition(animatingPosition);
                    }
                }
            }

            @Override
            public void onComplete(String finalText) {
                if (animatingPosition >= 0 && animatingPosition < messages.size()) {
                    messages.get(animatingPosition).setMessage(finalText);
                    notifyItemChanged(animatingPosition);
                }
                animatingPosition = -1;
                currentAnimator = null;
                if (callback != null) {
                    callback.onAnimationComplete();
                }
            }
        });

        currentAnimator.start();
    }

    /**
     * Stops the current typing animation and shows full text immediately.
     */
    public void stopCurrentAnimation() {
        if (currentAnimator != null && currentAnimator.isRunning()) {
            currentAnimator.completeImmediately();
            currentAnimator = null;
            animatingPosition = -1;
        }
    }

    /**
     * Returns whether a typing animation is currently running.
     */
    public boolean isAnimating() {
        return currentAnimator != null && currentAnimator.isRunning();
    }

    /**
     * Callback for typing animation completion.
     */
    public interface TypingAnimationCallback {
        void onAnimationComplete();
    }

    // ─────────────────────────────────────────────────
    // Item entrance animation
    // ─────────────────────────────────────────────────

    private void animateItem(View view) {
        AnimationSet set = new AnimationSet(true);

        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(300);

        TranslateAnimation slideUp = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, 0.15f,
                Animation.RELATIVE_TO_SELF, 0f
        );
        slideUp.setDuration(300);

        set.addAnimation(fadeIn);
        set.addAnimation(slideUp);
        set.setInterpolator(new DecelerateInterpolator());

        view.startAnimation(set);
    }

    /**
     * Formats timestamp for display.
     */
    private static String formatTime(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("h:mm a", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    // ─────────────────────────────────────────────────
    // ViewHolder: User Message
    // ─────────────────────────────────────────────────
    static class UserViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvMessage;
        private final TextView tvTime;

        UserViewHolder(View itemView) {
            super(itemView);
            tvMessage = itemView.findViewById(R.id.tvUserMessage);
            tvTime = itemView.findViewById(R.id.tvUserTime);
        }

        void bind(ChatMessage msg) {
            tvMessage.setText(msg.getMessage());
            tvTime.setText(formatTime(msg.getTimestamp()));
        }
    }

    // ─────────────────────────────────────────────────
    // ViewHolder: AI Message (with copy, error, header logic)
    // ─────────────────────────────────────────────────
    class AIViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvMessage;
        private final TextView tvTime;
        private final ImageView btnCopy;
        private final View aiHeaderRow;

        AIViewHolder(View itemView) {
            super(itemView);
            tvMessage = itemView.findViewById(R.id.tvAiMessage);
            tvTime = itemView.findViewById(R.id.tvAiTime);
            btnCopy = itemView.findViewById(R.id.btnCopy);
            aiHeaderRow = itemView.findViewById(R.id.aiHeaderRow);
        }

        void bind(ChatMessage msg, int position) {
            tvMessage.setText(msg.getMessage());
            tvTime.setText(formatTime(msg.getTimestamp()));

            // Error styling
            if (msg.isError()) {
                tvMessage.setBackgroundResource(R.drawable.chat_bubble_error);
                tvMessage.setTextColor(itemView.getContext().getColor(R.color.on_background));
            } else {
                tvMessage.setBackgroundResource(R.drawable.chat_bubble_ai);
                tvMessage.setTextColor(itemView.getContext().getColor(R.color.chat_ai_text));
            }

            // Hide header for consecutive AI messages
            if (position > 0 && !messages.get(position - 1).isUser()
                    && !messages.get(position - 1).isTyping()) {
                aiHeaderRow.setVisibility(View.GONE);
            } else {
                aiHeaderRow.setVisibility(View.VISIBLE);
            }

            // Hide copy button while animating
            boolean isBeingAnimated = (position == animatingPosition && isAnimating());
            btnCopy.setVisibility(isBeingAnimated ? View.INVISIBLE : View.VISIBLE);
            tvTime.setVisibility(isBeingAnimated ? View.INVISIBLE : View.VISIBLE);

            // Copy button
            btnCopy.setOnClickListener(v -> {
                Context ctx = v.getContext();
                ClipboardManager clipboard = (ClipboardManager)
                        ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("CampusAI Response", msg.getMessage());
                if (clipboard != null) {
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(ctx, "Copied to clipboard ✓", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // ─────────────────────────────────────────────────
    // ViewHolder: Typing Indicator (animated dots)
    // ─────────────────────────────────────────────────
    static class TypingViewHolder extends RecyclerView.ViewHolder {
        private final View dot1, dot2, dot3;

        TypingViewHolder(View itemView) {
            super(itemView);
            dot1 = itemView.findViewById(R.id.dot1);
            dot2 = itemView.findViewById(R.id.dot2);
            dot3 = itemView.findViewById(R.id.dot3);
        }

        void startAnimation() {
            animateDot(dot1, 0);
            animateDot(dot2, 200);
            animateDot(dot3, 400);
        }

        private void animateDot(View dot, long startDelay) {
            ObjectAnimator animator = ObjectAnimator.ofPropertyValuesHolder(dot,
                    PropertyValuesHolder.ofFloat("alpha", 0.3f, 1f, 0.3f),
                    PropertyValuesHolder.ofFloat("scaleX", 0.8f, 1.2f, 0.8f),
                    PropertyValuesHolder.ofFloat("scaleY", 0.8f, 1.2f, 0.8f)
            );
            animator.setDuration(1200);
            animator.setRepeatCount(ObjectAnimator.INFINITE);
            animator.setStartDelay(startDelay);
            animator.start();
        }
    }
}
