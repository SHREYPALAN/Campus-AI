package com.hardik.campusai.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.hardik.campusai.data.ChatRepository;
import com.hardik.campusai.models.ChatMessage;

import java.util.List;

/**
 * ViewModel for chat messages.
 * Survives configuration changes (screen rotation).
 * Exposes LiveData for the UI to observe.
 */
public class ChatViewModel extends AndroidViewModel {

    private final ChatRepository repository;
    private final LiveData<List<ChatMessage>> allMessages;

    public ChatViewModel(@NonNull Application application) {
        super(application);
        repository = new ChatRepository(application);
        allMessages = repository.getAllMessages();
    }

    /**
     * LiveData of all chat messages — observe this in your Fragment.
     */
    public LiveData<List<ChatMessage>> getAllMessages() {
        return allMessages;
    }

    /**
     * Saves a message to the database.
     */
    public void insert(ChatMessage message) {
        repository.insert(message);
    }

    /**
     * Clears all chat history.
     */
    public void clearChat() {
        repository.deleteAll();
    }
}
