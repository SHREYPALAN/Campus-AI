package com.hardik.campusai.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.hardik.campusai.models.ChatMessage;

/**
 * Room Database for CampusAI.
 * Singleton pattern — one instance shared across the app.
 */
@Database(entities = {ChatMessage.class}, version = 1, exportSchema = false)
public abstract class ChatDatabase extends RoomDatabase {

    private static volatile ChatDatabase INSTANCE;
    private static final String DATABASE_NAME = "campusai_chat_db";

    /**
     * Returns the DAO for chat messages.
     */
    public abstract ChatMessageDao chatMessageDao();

    /**
     * Returns the singleton database instance.
     * Thread-safe using double-checked locking.
     */
    public static ChatDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (ChatDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            ChatDatabase.class,
                            DATABASE_NAME
                    )
                    .fallbackToDestructiveMigration()
                    .build();
                }
            }
        }
        return INSTANCE;
    }
}
