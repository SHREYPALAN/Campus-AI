package com.hardik.campusai.models;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/**
 * Room Entity representing a chat message.
 * Stored in 'chat_messages' table.
 */
@Entity(tableName = "chat_messages")
public class ChatMessage {

    public static final int TYPE_USER = 0;
    public static final int TYPE_AI = 1;
    @Ignore
    public static final int TYPE_TYPING = 2;  // Never saved to DB

    @PrimaryKey(autoGenerate = true)
    private long id;

    @ColumnInfo(name = "message")
    private String message;

    @ColumnInfo(name = "type")
    private int type;

    @ColumnInfo(name = "timestamp")
    private long timestamp;

    @ColumnInfo(name = "is_error")
    private boolean isError;

    // ─── Room requires a no-arg or all-args constructor ───
    // This is the constructor Room will use (matches all fields)
    public ChatMessage(String message, int type, long timestamp, boolean isError) {
        this.message = message;
        this.type = type;
        this.timestamp = timestamp;
        this.isError = isError;
    }

    // ─── Convenience constructor (not used by Room) ───
    @Ignore
    public ChatMessage(String message, int type) {
        this.message = message;
        this.type = type;
        this.timestamp = System.currentTimeMillis();
        this.isError = false;
    }

    // ─── Static factory methods ───

    @Ignore
    public static ChatMessage userMessage(String text) {
        return new ChatMessage(text, TYPE_USER);
    }

    @Ignore
    public static ChatMessage aiMessage(String text) {
        return new ChatMessage(text, TYPE_AI);
    }

    @Ignore
    public static ChatMessage typingIndicator() {
        return new ChatMessage("", TYPE_TYPING);
    }

    @Ignore
    public static ChatMessage errorMessage(String text) {
        ChatMessage msg = new ChatMessage(text, TYPE_AI);
        msg.setError(true);
        return msg;
    }

    // ─── Getters & Setters (Room needs these) ───

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public boolean isError() {
        return isError;
    }

    public void setError(boolean error) {
        isError = error;
    }

    // ─── Convenience methods ───

    @Ignore
    public boolean isUser() {
        return type == TYPE_USER;
    }

    @Ignore
    public boolean isTyping() {
        return type == TYPE_TYPING;
    }
}
