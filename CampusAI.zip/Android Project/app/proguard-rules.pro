# CampusAI ProGuard Rules
# Keep Retrofit models
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.hardik.campusai.models.** { *; }
-keep class com.hardik.campusai.api.** { *; }
